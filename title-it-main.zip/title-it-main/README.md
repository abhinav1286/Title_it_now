# Title it
- Lazy enough to find unique domain name or any project name ?
- Just type the relevant character and vola the magic happens!! 
  - To check whether the particular name domain exist or not , just click on the word itself.
